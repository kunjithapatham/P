package routines;

import com.csvreader.CsvReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



public class CSVReader {

	public static void print() {
		System.out.println("CSVReader");
	}
    
   
	public void readCSV( String fileName ) {
		
		try {
			
			CsvReader campaign = new CsvReader(fileName);
		
			campaign.readHeaders();
			
			List<String[]> records = new ArrayList<String[]>();
			
			while (campaign.readRecord())
			{
				int col = campaign.getColumnCount();
				String[] record = new String[col];
				
				//read each column value into record
				for(int i=0; i<col; i++) {
										
					record[i] = campaign.get(i);					
					System.out.print(" | " + record[i]);
						
				}
				System.out.println();
				records.add(record);
			}
	
			campaign.close();
			System.out.println("records............\n"+records.toString());
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}

