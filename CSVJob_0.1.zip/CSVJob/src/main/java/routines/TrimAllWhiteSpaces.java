package routines;

public class TrimAllWhiteSpaces {

	public static String trim(String str) {
		
		System.out.println(str);
		String trimmedStr;
		
		
		char charArray[] = str.toCharArray();
		char trimmedArray[] = new char[charArray.length];
		
		for(int i=0, j=0; i<charArray.length; i++) {
			
			if(Character.isWhitespace(charArray[i]))
				continue;
			else 
				trimmedArray[j++] = charArray[i];
			
		}
		
		trimmedStr = new String(trimmedArray).trim();
		System.out.println("begin:"+trimmedStr+":end");
		
		return trimmedStr;
		
	}

}