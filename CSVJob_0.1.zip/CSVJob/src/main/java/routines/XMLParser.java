package routines;

public class XMLParser {

	private String g_strdoc;
	private org.w3c.dom.Document xml;
	public org.w3c.dom.Node rootnode;
	
	public boolean hasError;
	
	public XMLParser()
	{
	}
	
	public XMLParser(String m_source)
	{
		hasError = false;
		
		g_strdoc = m_source;
		
		initDocument();
	}
	
	private void initDocument()
	{
		try
		{
			if (g_strdoc.endsWith("\r\n") == true)
			{
				g_strdoc = g_strdoc.substring(0, g_strdoc.length() - "\r\n".length());
			}
			
			if (g_strdoc.startsWith("<") == true && g_strdoc.endsWith("/>") == true)
			{
				int n = g_strdoc.indexOf(" ");
				String nodename = g_strdoc.substring(1, n);
				g_strdoc = g_strdoc.substring(0, g_strdoc.length() - "/>".length());
				g_strdoc = g_strdoc + "></" + nodename + ">";
			}
			
			javax.xml.parsers.DocumentBuilderFactory docBuilderFactory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
			javax.xml.parsers.DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			java.io.StringReader sr = new java.io.StringReader(g_strdoc);
			org.xml.sax.InputSource is = new org.xml.sax.InputSource(sr);
			
			xml = docBuilder.parse (is);
			xml.getDocumentElement().normalize();
			
			rootnode = xml.getDocumentElement();
		}
		catch (Exception e)
		{
			hasError = true;
			// System.out.println(g_strdoc);
			// String key = ClassUtils.generateUID();
			// OSUtil.writeToFile("/u01/orbit/orbit_rwb/temp", "error_xml " + key + ".xml", g_strdoc);
			e.printStackTrace();
		}
	}
	
	public org.w3c.dom.Document getDocument()
	{
		return xml;
	}
	
	public org.w3c.dom.Node RootNode()
	{
		return rootnode;
	}
	
	public org.w3c.dom.Node createNode(String nodename)
	{
		org.w3c.dom.Element nnode = xml.createElement(nodename);
		return nnode;
	}
	
	public org.w3c.dom.Node GetXMLNode(org.w3c.dom.Node unode, String path)
	{
		org.w3c.dom.Node nd = null;
		
		java.util.StringTokenizer tok = new java.util.StringTokenizer(path, "/");
		String fname = "";
		
		if (path.charAt(0) == '/' && tok.hasMoreElements() == false)
		{
			return unode;
		}
		
		if (tok.hasMoreElements() == true)
		{
			fname = tok.nextElement().toString();
		}
		
		if (!unode.getNodeName().equals(fname))
		{
			System.out.println("Warn: XMLNode path error " + path + ":" + unode.getNodeName());
			return null;
		}
		
		while (tok.hasMoreElements())
		{
			fname = tok.nextElement().toString();
			
			if (!fname.equals(""))
			{
				unode = findChildNode(unode, fname);
				
				if (unode == null)
					break;
			}
		}
		
		nd = unode;
		
		return nd;
	}
	
	public org.w3c.dom.Node GetXMLSubNode(org.w3c.dom.Node unode, String path)
	{
		org.w3c.dom.Node nd = null;
		
		java.util.StringTokenizer tok = new java.util.StringTokenizer(path, "/");
		String fname = "";
		
		if (path.charAt(0) == '/' && tok.hasMoreElements() == false)
		{
			return unode;
		}
		
		if (tok.hasMoreElements() == true)
		{
			fname = tok.nextElement().toString();
		}
		
		if (path.charAt(0) == '/' && !unode.getNodeName().equals(fname))
		{
			System.out.println("Warn: XMLNode path error " + path + ":" + unode.getNodeName());
			return null;
		}
		else if (path.charAt(0) == '/')
		{
			fname = tok.nextElement().toString();
		}
		else
		{
			unode = findChildNode(unode, fname);
			
			if (tok.hasMoreTokens())
			{
				fname = tok.nextElement().toString();
				if (unode != null)
				{
					unode = findChildNode(unode, fname);
				}
			}
			else
			{
				fname = null;
			}
		}
		
		if (unode != null)
		{
			while (tok.hasMoreElements())
			{
				fname = tok.nextToken().toString();
				if (fname != null && fname.equals("") == false)
				{
					unode = findChildNode(unode, fname);
					
					if (unode == null)
						break;
				}
			}
		}
		
		nd = unode;
		
		return nd;
	}
	
	private org.w3c.dom.Node findChildNode(org.w3c.dom.Node unode, String path)
	{
		org.w3c.dom.Node nd = null;
		int i;
		
		for (i=0; i < unode.getChildNodes().getLength(); i++)
		{
			String nodename = unode.getChildNodes().item(i).getNodeName();
			if (nodename.equals(path) || (nodename.equals("") == false && path.equals("*") == true))
			{
				nd = unode.getChildNodes().item(i);
				break;
			}
		}
		
		return nd;
	}
	
	public String GetNodeName(org.w3c.dom.Node node)
	{
		return node.getNodeName();
	}
	
	public String GetElementValue(org.w3c.dom.Node node, String name)
	{
		java.util.Properties prop = GetElements(node);
		String value = "";
		
		if (prop.getProperty(name) != null)
			value = prop.getProperty(name);
		
		return value;
	}
	
	public java.util.Properties GetElements(org.w3c.dom.Node node)
	{
		return GetElements(node, true);
	}
	
	public String GetSubNodeText(org.w3c.dom.Node node, String nodename)
	{
		String r = null;
		org.w3c.dom.Node snode = findChildNode(node, nodename);
		if (snode != null)
		{
			r = getTextContent(snode);
		}
		return r;
	}
	
	public java.util.Properties GetElements(org.w3c.dom.Node node, boolean casesensitive)
	{
		int i;
		java.util.Properties prop = new java.util.Properties();
		
		String strkey;
		String strvalue;
		
		for (i=0; i < node.getAttributes().getLength(); i++)
		{
			strkey = node.getAttributes().item(i).getNodeName();
			if (casesensitive == false)
			{
				strkey = strkey.toLowerCase();
			}
			strvalue = node.getAttributes().item(i).getNodeValue();
			
			prop.setProperty(strkey, strvalue);
		}
		
		return prop;
	}
	

	public String getTextContent(org.w3c.dom.Node node)
	{
		String r = null;
		
		if (node != null && node.hasChildNodes() == true)
		{
			org.w3c.dom.Node cnode = null;
			
			for (int i=0; i < node.getChildNodes().getLength(); i++)
			{
				cnode = node.getChildNodes().item(i);
				
				if (cnode.getNodeType() == org.w3c.dom.Node.TEXT_NODE || cnode.getNodeType() == org.w3c.dom.Node.CDATA_SECTION_NODE)
				{
					r = cnode.getNodeValue();
					break;
				}
				else if (cnode.getNodeType() == org.w3c.dom.Node.ELEMENT_NODE)
				{
					r = getTextContent(cnode);
				}
			}
		}
		
		return r;
	}

	public boolean hasOwnProperty(org.w3c.dom.Node node, String value)
	{
		boolean inc = false;
		
		for (int i=0; i < node.getChildNodes().getLength(); i++)
		{
			if (node.getChildNodes().item(i).getNodeName().equals(value) == true)
			{
				inc = true;
				break;
			}
		}
		
		return inc;
	}
	
	public java.util.List <org.w3c.dom.Node> getChildNode(org.w3c.dom.Node node)
	{
		java.util.List <org.w3c.dom.Node> nlist = new java.util.ArrayList <org.w3c.dom.Node> ();
		
		for (int i=0; i < node.getChildNodes().getLength(); i++)
		{
			org.w3c.dom.Node n = node.getChildNodes().item(i);
			String nodename = n.getNodeName();
			Short nodetype = n.getNodeType();
			if (nodename.equals("") == false && nodetype == org.w3c.dom.Node.ELEMENT_NODE)
			{
				nlist.add(n);
			}
		}
		
		return nlist;
	}
}
